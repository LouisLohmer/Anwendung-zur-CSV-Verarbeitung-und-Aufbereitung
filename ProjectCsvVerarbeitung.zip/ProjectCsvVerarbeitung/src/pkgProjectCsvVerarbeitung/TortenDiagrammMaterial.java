package pkgProjectCsvVerarbeitung;

//javafx
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.stage.Stage;

public class TortenDiagrammMaterial extends Application {

	public void start(Stage primaryStage) {
		 /**
		  * Erstellen der Daten des Tortendiagramms mithilfe JavaFX
		  */
		 ObservableList<PieChart.Data> daten = FXCollections.observableArrayList(
				 new PieChart.Data("Bio-Baumwolle", 40),
				 new PieChart.Data("Baumwolle", 35),
				 new PieChart.Data("Viskose", 10),
		         new PieChart.Data("Bio-Bauwoll-Gemisch", 10));

		 //Erstellen des Tortendiagramms mithilfe JavaFX
		 PieChart tortenDiagramm = new PieChart(daten);
		 
		 /**
		 tortenDiagramm.getData().forEach(data -> {
			 String prozent = String.format("%.2f%%", (data.getPieValue() / 100));//Umwandeln der Daten in Prozent-Format
			 Tooltip toolTip = new Tooltip(prozent);//Anzeigen der genauen Prozentangabe
			 Tooltip.install(data.getNode(), toolTip);
		  });
		 */
		 
		 Group form = new Group(tortenDiagramm);
		 Scene szene = new Scene(form, 500, 400);//Verstellen der GUI
		 primaryStage.setTitle("Prozentangaben zum Material der ersten 20 Datensätze");//Titel des Diagramms
		 primaryStage.setScene(szene); 
		 primaryStage.show();//Zeigt das Tortendiagramm
		}
	
	public static void main(String[] args) {
		launch(args);
	 }

}

