package pkgProjectCsvVerarbeitung;

//javafx
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.stage.Stage;

public class TortenDiagrammAermel extends Application {

	@Override
	public void start(Stage primaryStage2) throws Exception {
		// TODO Auto-generated method stub
		 /**
		  * Erstellen der Daten des Tortendiagramms mithilfe JavaFX
		  */
		ObservableList<PieChart.Data> daten2 = FXCollections.observableArrayList(
			new PieChart.Data("Kurzarm", 80),
			new PieChart.Data("Ärmellos", 15),
			new PieChart.Data("Kurzarm", 5));
		
		//Erstellen des Tortendiagramms mithilfe JavaFX
		PieChart tortenDiagramm2 = new PieChart(daten2);
		
		Group form = new Group(tortenDiagramm2);
		Scene szene = new Scene(form, 500, 450);//Verstellen der GUI
		primaryStage2.setTitle("Prozentangaben zu den Ärmeln der ersten 20 Datensätze");//Titel des Diagramms
		primaryStage2.setScene(szene); 
	    primaryStage2.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	 }

}
