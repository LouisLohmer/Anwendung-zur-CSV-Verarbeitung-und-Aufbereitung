package pkgProjectCsvVerarbeitung;


//Libraries des Frontends
import java.awt.EventQueue;
import javax.swing.JFrame;
import java.awt.SystemColor;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JTextField;


//Hinzugefügte Java Libraries
//java.io
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


//java.swing
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JFileChooser;


//java.awt
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AnwendungGUI extends TortenDiagrammMaterial{
	
	
	//Konstruktor
	private File datei;
	private File neueDatei;
	private JFrame frame;
	private JTable table;
	private DefaultTableModel modellUeberschrift;
	private DefaultTableModel modellEinlesen;
	private JButton neuerDatensatz;
	private JLabel lblArtikelname;
	private JLabel lblHersteller;
	private JLabel lblMaterialangabe;
	private JLabel lblGeschlecht;
	private JLabel lblProduktart;
	private JLabel lblrmel;
	private JLabel lblBein;
	private JLabel lblKragen;
	private JLabel lblHerstellung;
	private JLabel lblTaschenart;
	private JLabel lblGrammatur;
	private JLabel lblMaterial;
	private JLabel lblBildname;
	private JLabel lblHauptartikel;
	private JLabel lblUrsprungsland;
	private JTextField hauptartikel;
	private JTextField artikelname;
	private JTextField hersteller;
	private JTextField materialangabe;
	private JTextField geschlecht;
	private JTextField produktart;
	private JTextField aermel;
	private JTextField bein;
	private JTextField kragen;
	private JTextField herstellung;
	private JTextField taschenart;
	private JTextField grammatur;
	private JTextField material;
	private JTextField bildname;
	private JTextField ursprungsland;	
	
	
	//Main-Methode, welche die GUI ausführt
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AnwendungGUI window = new AnwendungGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	//GUI erstellt
	public AnwendungGUI() {
		initialize();
	}

		//Elemente der GUI erstellt
		private void initialize() {
		frame = new JFrame("CSV-Verarbeitung und -Aufbereitungsanwendung");
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);//GUI wird im Vollbildschirm angezeigt
		frame.getContentPane().setBackground(SystemColor.inactiveCaption);
		frame.setBounds(100, 100, 1968, 651);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		//JLabel erstellt
		lblHauptartikel = new JLabel("Hauptartikel");
		lblHauptartikel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblHauptartikel.setBounds(10, 327, 96, 14);
		frame.getContentPane().add(lblHauptartikel);
				
				
		//JLabel erstellt
		lblArtikelname = new JLabel("Artikelname");
		lblArtikelname.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblArtikelname.setBounds(10, 351, 96, 14);
		frame.getContentPane().add(lblArtikelname);
				
				
		//JLabel erstellt
		lblHersteller = new JLabel("Hersteller");
		lblHersteller.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblHersteller.setBounds(10, 376, 96, 14);
		frame.getContentPane().add(lblHersteller);
				
				
		//JLabel erstellt
		lblMaterialangabe = new JLabel("Materialangabe");
		lblMaterialangabe.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblMaterialangabe.setBounds(10, 401, 111, 23);
		frame.getContentPane().add(lblMaterialangabe);
				
				
		//JLabel erstellt
		lblGeschlecht = new JLabel("Geschlecht");
		lblGeschlecht.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblGeschlecht.setBounds(10, 426, 96, 14);
		frame.getContentPane().add(lblGeschlecht);
				
				
		//JLabel erstellt
		lblProduktart = new JLabel("Produktart");
		lblProduktart.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblProduktart.setBounds(10, 451, 96, 14);
		frame.getContentPane().add(lblProduktart);
				
				
		//JLabel erstellt
		lblrmel = new JLabel("Ärmel");
		lblrmel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblrmel.setBounds(10, 476, 96, 14);
		frame.getContentPane().add(lblrmel);
				
				
		//JLabel erstellt
		lblBein = new JLabel("Bein");
		lblBein.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblBein.setBounds(10, 501, 96, 14);
		frame.getContentPane().add(lblBein);
				
				
		//JLabel erstellt
		lblKragen = new JLabel("Kragen");
		lblKragen.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblKragen.setBounds(10, 526, 96, 14);
		frame.getContentPane().add(lblKragen);
				
				
		//JLabel erstellt
		lblHerstellung = new JLabel("Herstellung");
		lblHerstellung.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblHerstellung.setBounds(10, 551, 96, 19);
		frame.getContentPane().add(lblHerstellung);
				
				
		//JLabel erstellt
		lblTaschenart = new JLabel("Taschenart");
		lblTaschenart.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblTaschenart.setBounds(10, 576, 96, 14);
		frame.getContentPane().add(lblTaschenart);
				
				
		//JLabel erstellt
		lblGrammatur = new JLabel("Grammatur");
		lblGrammatur.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblGrammatur.setBounds(276, 327, 96, 14);
		frame.getContentPane().add(lblGrammatur);
				
				
		//JLabel erstellt
		lblMaterial = new JLabel("Material");
		lblMaterial.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblMaterial.setBounds(276, 353, 96, 14);
		frame.getContentPane().add(lblMaterial);
				
				
		//JLabel erstellt
		JLabel lblUrspungsland = new JLabel("Ursprungsland");
		lblUrspungsland.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblUrspungsland.setBounds(276, 378, 111, 14);
		frame.getContentPane().add(lblUrspungsland);
				
				
		//JLabel erstellt
		lblBildname = new JLabel("Bildname");
		lblBildname.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblBildname.setBounds(276, 403, 96, 14);
		frame.getContentPane().add(lblBildname);
				
				
		//JTextfield erstellt
		hauptartikel = new JTextField();
		hauptartikel.setBounds(121, 325, 145, 20);
		frame.getContentPane().add(hauptartikel);
		hauptartikel.setColumns(10);
				
				
		//JTextfield erstellt
		artikelname = new JTextField();
		artikelname.setColumns(10);
		artikelname.setBounds(121, 350, 145, 20);
		frame.getContentPane().add(artikelname);
				
				
		//JTextfield erstellt
		hersteller = new JTextField();
		hersteller.setColumns(10);
		hersteller.setBounds(121, 375, 145, 20);
		frame.getContentPane().add(hersteller);
				
				
		//JTextfield erstellt
		materialangabe = new JTextField();
		materialangabe.setColumns(10);
		materialangabe.setBounds(121, 400, 145, 20);
		frame.getContentPane().add(materialangabe);
				
				
		//JTextfield erstellt
		geschlecht = new JTextField();
		geschlecht.setColumns(10);
		geschlecht.setBounds(121, 425, 145, 20);
		frame.getContentPane().add(geschlecht);
				
		//JTextfield erstellt
		produktart = new JTextField();
		produktart.setColumns(10);
		produktart.setBounds(121, 450, 145, 20);
		frame.getContentPane().add(produktart);
				
				
		//JTextfield erstellt
		aermel = new JTextField();
		aermel.setColumns(10);
		aermel.setBounds(121, 475, 145, 20);
		frame.getContentPane().add(aermel);
				
				
		//JTextfield erstellt
		bein = new JTextField();
		bein.setColumns(10);
		bein.setBounds(121, 500, 145, 20);
		frame.getContentPane().add(bein);
				
				
		//JTextfield erstellt
		kragen = new JTextField();
		kragen.setColumns(10);
		kragen.setBounds(121, 525, 145, 20);
			frame.getContentPane().add(kragen);
				
				
		//JTextfield erstellt
		herstellung = new JTextField();
		herstellung.setColumns(10);
		herstellung.setBounds(121, 550, 145, 20);
		frame.getContentPane().add(herstellung);
				
				
		//JTextfield erstellt
		taschenart = new JTextField();
		taschenart.setColumns(10);
		taschenart.setBounds(121, 575, 145, 20);
		frame.getContentPane().add(taschenart);
				
				
		//JTextfield erstellt
		grammatur = new JTextField();
		grammatur.setColumns(10);
		grammatur.setBounds(393, 327, 167, 20);
		frame.getContentPane().add(grammatur);
				
				
		//JTextfield erstellt
		material = new JTextField();
		material.setColumns(10);
		material.setBounds(393, 350, 167, 20);
		frame.getContentPane().add(material);
				
				
		//JTextfield erstellt
		ursprungsland = new JTextField();
		ursprungsland.setColumns(10);
		ursprungsland.setBounds(393, 375, 167, 20);
		frame.getContentPane().add(ursprungsland);
				
				
		//JTextfield erstellt
		bildname = new JTextField();
		bildname.setColumns(10);
		bildname.setBounds(393, 400, 167, 20);
		frame.getContentPane().add(bildname);
		
		
		//JScrollPane erstellt
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 1910, 305);
		frame.getContentPane().add(scrollPane);
				
				
		//JTable erstellt
		table = new JTable();
		table.setBackground(SystemColor.window);
		scrollPane.setViewportView(table);
				
		modellUeberschrift = new DefaultTableModel();//Erstellt ein neues Modell für die Spaltenbezeichnungen
		Object [] column = {"Hauptartikel","Artikelname","Hersteller","Materialangabe","Geschlecht"
							,"Produktart","Ärmel","Bein","Kragen","Herstellung","Taschenart",
							"Grammatur","Material","Ursprungsland","Bildname"};//Überschriften
		final Object[] row = new Object[15];
		modellUeberschrift.setColumnIdentifiers(column);
		table.setModel(modellUeberschrift);
		
		
		//JButton  fürs Importieren erstellt	
		JButton importiereDatei = new JButton("Datei importieren");	
		importiereDatei.setBackground(SystemColor.controlHighlight);
		importiereDatei.setBounds(355, 483, 205, 23);
		frame.getContentPane().add(importiereDatei);
				
		importiereDatei.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				/**
				* JButton wird auf eine bestimmte Funktion programmiert
				* In diesem Fall ist dies das Importieren einer bestehenden Datei, die dann in der Liste angezeigt wird
				*/
				JFileChooser dateienDurchsuchen = new JFileChooser();
				dateienDurchsuchen.setDialogTitle("Importieren einer Datei");
				int i = dateienDurchsuchen.showOpenDialog(null);//Öffnet Windows Explorer in Java, somit ist jede csv-Datei importierbar ins Zielssystem
										 
				if (i == JFileChooser.APPROVE_OPTION) {
					/**
					* Wenn eine Datei erfolgreich ausgewählt wurde, wird diese im Programm als Datei, unter einer Variable, gespeichert
					* Zudem wird eine positive Bestätigung in Form einer Nachricht angezeigt
					*/
					datei = dateienDurchsuchen.getSelectedFile();
					JOptionPane.showMessageDialog(null, "Datei erfolgreich importiert!", "Nachricht", 1);
											    
					try {
													
					BufferedReader br = new BufferedReader(new FileReader(datei));//Einlesen der Daten
					String reader = br.readLine();//BufferedReader liest Zeilen des Dokumentes
					modellEinlesen = new DefaultTableModel(reader.split("\\s+"), 0);//Erstellt ein neues Modell, um Dateien einzulesen in den JTable
					/**
					* Erstellt ein neues Modell für das Einlesen der Daten aus der importierten Datei
					*/
					while ((reader = br.readLine()) != null) {
					/**
					* Solange die Zeile im Dokument existiert, wird sie ausgelesen 
					*/
					String[] werte = reader.split(";;");//Differenzieren der Sätze durch ";;"
					modellEinlesen.addRow(werte);//Modell wird auf GUI angewendet  	
					}
											
					} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
					} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
					}  
							table.setModel(modellEinlesen);//Modell wird auf die GUI angewendet
					} 
					else {
						JOptionPane.showMessageDialog(null, "Fehler beim importieren der Datei", "Nachricht", 2);
					}
				}
									
		} );
		 
				
		//JButton  für neue Datensätze erstellt
		neuerDatensatz = new JButton("Neuen Datensatz hinzufügen");
		neuerDatensatz.setBackground(SystemColor.controlHighlight);
		neuerDatensatz.setBounds(355, 449, 205, 23);
		frame.getContentPane().add(neuerDatensatz);
		frame.getContentPane().add(neuerDatensatz);
				
		neuerDatensatz.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					/**
					* JButton wird auf eine bestimmte Funktion programmiert
					* In diesem Fall ist dies das hinzufügen eines neues Datensatzes
					*/				
					if (hauptartikel.getText().equals("") || artikelname.getText().equals("") || hersteller.getText().equals("") 
						|| materialangabe.getText().equals("") || geschlecht.getText().equals("") || aermel.getText().equals("")
						|| bein.getText().equals("") || kragen.getText().equals("") || herstellung.getText().equals("")
						|| taschenart.getText().equals("") || grammatur.getText().equals("") || material.getText().equals("")
						|| ursprungsland.getText().equals("") || bildname.getText().equals("")) {
						/**
						* Wenn ein Feld leer ist, wird der Benutzer zu einer Angabe aufgefordert
						*/
						JOptionPane.showMessageDialog(null, "Bitte fülle alle Felder aus!", "Nachricht", 2);
						}
						else {
											
							row[0] = hauptartikel.getText();
							row[1] = artikelname.getText();
							row[2] = hersteller.getText();
							row[3] = materialangabe.getText();
							row[4] = geschlecht.getText();
							row[5] = produktart.getText();
							row[6] = aermel.getText();
							row[7] = bein.getText();
							row[8] = kragen.getText();
							row[9] = herstellung.getText();
							row[10] = taschenart.getText();
							row[11] = grammatur.getText();
							row[12] = material.getText();
							row[13] = ursprungsland.getText();
							row[14] = bildname.getText();
							modellUeberschrift.addRow(row);//Neue Reihe wird in JTable hinzugefügt
											
							}
					}
									
		} );
		
		
		//JButton  fürs Exportieren erstellt
		JButton exportiereDatei = new JButton("Datei exportieren");
		exportiereDatei.setBackground(SystemColor.controlHighlight);
		exportiereDatei.setBounds(355, 517, 205, 23);
		frame.getContentPane().add(exportiereDatei);
		
		exportiereDatei.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				/**
				* JButton wird auf eine bestimmte Funktion programmiert
				* In diesem Fall ist dies das Exportieren der
				*/
				JFileChooser dateienDurchsuchen2 = new JFileChooser();
				dateienDurchsuchen2.setDialogTitle("Exportieren einer Datei");
				int a = dateienDurchsuchen2.showSaveDialog(null);//Öffnet Windows Explorer in Java, somit ist jede csv-Datei wieder exportierbar ins Quellsystem
							
				if (a == JFileChooser.APPROVE_OPTION) {
					/**
					* Wenn eine Datei erfolgreich ausgewählt wurde, wird diese im Programm als Datei, unter einer Variable, gespeichert
					*/
					neueDatei = dateienDurchsuchen2.getSelectedFile();
					JOptionPane.showMessageDialog(null, "Datei erfolgreich gespeichert", "Nachricht", 1);
								
					try {
									
						FileWriter fw = new FileWriter(neueDatei);//Speichert die ausgewählte Datei als Datei ab
						BufferedWriter bw = new BufferedWriter(fw);//Auslesen und  Schreiben der Daten
									
						for (int i = 0;i < table.getRowCount();i++) {
							/**
							* Solange i nicht der Anzahl der Reihen gleicht, läuft die Schleife weiter
							* Zählt die Anzahl der Reihen in der Liste
							*/
							for (int j = 0;j < table.getColumnCount();j++) {
								/**
								* Solange j nicht der Anzahl der Spalten gleicht, läuft die Schleife weiter
								* Zählt die Anzahl der Spalten in der Liste
								*/
								bw.write(table.getValueAt(i, j).toString());
								/**
								* BufferedWriter schreibt die Daten in die Datei in Form eines Strings
								*/
								}
								bw.newLine();//Neue Zeile
								}
									
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
					}
				else {
						JOptionPane.showMessageDialog(null, "Fehler beim exportieren der Datei", "Nachricht", 2);
					}
			} 
	} );
		
		
		//JButton für das Anzeigen des Tortendiagramms erstellt
		final JButton anzeigenDiagramm = new JButton("Tortendiagramm anzeigen");
		anzeigenDiagramm.setBackground(SystemColor.controlHighlight);
		anzeigenDiagramm.setBounds(355, 551, 205, 23);
		frame.getContentPane().add(anzeigenDiagramm);
				
		anzeigenDiagramm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/**
				* Main-Methode des anderen Programms aufgrund von Vererbung durch "extends" aufrufbar
				*/
				TortenDiagrammMaterial.main(null);
				
			}
		} );
	
		
				
	}
}
